<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip/archiviste.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'archiviste_description' => 'Permet d’emballer ou déballer des archives de fichiers Zip, Tar, …',
	'archiviste_nom' => 'Archiviste',
	'archiviste_slogan' => 'Gérer des archives de fichiers'
);
