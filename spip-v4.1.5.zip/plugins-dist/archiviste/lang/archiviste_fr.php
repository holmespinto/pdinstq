<?php

$GLOBALS[$GLOBALS['idx_lang']] = [
	'OK' => 'OK',
	'erreur_inconnue' => 'Erreur inconnue',
	'extension_inconnue' => 'Extension inconnue',
	'fichier_absent' => 'Fichier absent',
	'fichier_lecture_seule' => 'Fichier en lecture seule',
	'destination_inaccessible' => 'Desination inaccessible',
	'fichier_deja_existant' => 'Le fichier existe d&eacute;j&agrave;',
	'tentative_de_vidage_du_fichier' => 'Impossible de vider totalement un fichier d\'archive',
];
