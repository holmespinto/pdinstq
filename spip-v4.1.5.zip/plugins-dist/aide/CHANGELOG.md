# Changelog

## [3.0.5] - 2022-07-21

### Changed

- Mise à jour des chaînes de langues depuis trad.spip.net

## [3.0.4] - 2022-05-20

## Added

- Fichier `CHANGELOG.md`

### Changed

- Mise à jour des chaînes de langues depuis trad.spip.net

## [3.0.3] - 2022-03-25

### Changed

- Compatible SPIP 4.1.0 minimum

## [3.0.2] - 2022-03-05

### Changed

- Mise à jour des chaînes de langues depuis trad.spip.net

## [3.0.1] - 2022-02-17

### Changed

- Mise à jour des chaînes de langues depuis trad.spip.net

## [3.0.0] - 2022-02-08

### Added

- Ajout du fichier `resume.spip` en anglais.

### Changed

- Nécessite PHP 7.4 minimum
