<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-aide?lang_cible=fr_tu
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aide_description' => 'Ce plugin permet d’inclure dans SPIP une aide contextuelle repérée par une icone. Cette aide peut-être étendue aussi aux plugins.',
	'aide_nom' => 'Aide SPIP',
	'aide_slogan' => 'Aide en ligne de SPIP'
);
