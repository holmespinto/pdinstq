<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/aide-aide?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'Typografische Abkürzungen',
	'raccourcis_ancre' => 'Benannte Anker',
	'raccourcis_citation' => 'Zitate',
	'raccourcis_code' => 'Programmiercode',
	'raccourcis_glossaire' => 'Externes Glossar',
	'raccourcis_lien' => 'Hyperlinks',
	'raccourcis_liste' => 'Listen und Aufzählungen',
	'raccourcis_note' => 'Fußnoten',
	'raccourcis_resume' => 'In Kürze',
	'raccourcis_simple' => 'Einfache Formatierung',
	'raccourcis_tableau' => 'Tabelle'
);
