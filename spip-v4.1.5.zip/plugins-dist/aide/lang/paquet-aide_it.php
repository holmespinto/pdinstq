<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-aide?lang_cible=it
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aide_description' => 'Questo plugin consente a SPIP di includere una guida contestuale contrassegnata da un’icona. Questo aiuto può essere esteso anche ai plugin.',
	'aide_nom' => 'Aiuto SPIP',
	'aide_slogan' => 'Guida in linea di SPIP'
);
