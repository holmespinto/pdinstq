<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/aide-aide?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'Atalhos tipográficos',
	'raccourcis_ancre' => 'Âncoras nomeadas',
	'raccourcis_citation' => 'Citações',
	'raccourcis_code' => 'Código de programação',
	'raccourcis_glossaire' => 'Glossário externo',
	'raccourcis_lien' => 'Links de hipertexto',
	'raccourcis_liste' => 'Listas e enumerações',
	'raccourcis_note' => 'Notas de pé de página',
	'raccourcis_resume' => 'Resumo',
	'raccourcis_simple' => 'Formatação simples',
	'raccourcis_tableau' => 'Tabelas'
);
