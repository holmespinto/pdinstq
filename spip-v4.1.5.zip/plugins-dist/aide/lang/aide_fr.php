<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip/aide.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'Raccourcis typographiques',
	'raccourcis_ancre' => 'Ancres nommées',
	'raccourcis_citation' => 'Citations',
	'raccourcis_code' => 'Code informatique',
	'raccourcis_glossaire' => 'Glossaire externe',
	'raccourcis_lien' => 'Liens hypertextes',
	'raccourcis_liste' => 'Listes et énumérations',
	'raccourcis_note' => 'Notes de bas de page',
	'raccourcis_resume' => 'En résumé',
	'raccourcis_simple' => 'Mise en forme simple',
	'raccourcis_tableau' => 'Tableaux'
);
