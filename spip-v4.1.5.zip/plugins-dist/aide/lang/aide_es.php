<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/aide-aide?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'Atajos',
	'raccourcis_ancre' => 'Anclas con nombres',
	'raccourcis_citation' => 'Citar un extracto',
	'raccourcis_code' => 'Mostrar código informático',
	'raccourcis_glossaire' => 'Glosario externo',
	'raccourcis_lien' => 'Enlaces de hipertexto',
	'raccourcis_liste' => 'Listas y enumeraciones',
	'raccourcis_note' => 'Notas de pie de página',
	'raccourcis_resume' => 'En resumen',
	'raccourcis_simple' => 'Formato simple',
	'raccourcis_tableau' => 'Tablas'
);
