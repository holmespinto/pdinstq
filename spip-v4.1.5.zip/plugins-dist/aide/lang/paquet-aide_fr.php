<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip/aide.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aide_description' => 'Ce plugin permet d’inclure dans SPIP une aide contextuelle repérée par un icone. Cette aide peut-être étendue aussi aux plugins.',
	'aide_nom' => 'Aide SPIP',
	'aide_slogan' => 'Aide en ligne de SPIP'
);
