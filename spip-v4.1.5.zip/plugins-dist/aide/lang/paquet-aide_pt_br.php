<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-aide?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aide_description' => 'Este plugin permite incluir ajuda contextual no SPIP, acessível por um ícone. Esta ajuda pode ser também extendida aos plugins.',
	'aide_nom' => 'Ajuda do SPIP',
	'aide_slogan' => 'Ajuda online do SPIP'
);
