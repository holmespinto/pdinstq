<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/aide-aide?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'إختصارات الكتابة',
	'raccourcis_ancre' => 'مراسي تحمل اسماء',
	'raccourcis_citation' => 'ذكر مقتطفات',
	'raccourcis_code' => 'عرض الرموز البرمجية',
	'raccourcis_glossaire' => 'معجم خارجي',
	'raccourcis_lien' => 'روابط هايبرتكست',
	'raccourcis_liste' => 'اللوائح والترقيم',
	'raccourcis_note' => 'الحواشي',
	'raccourcis_resume' => 'باختصار',
	'raccourcis_simple' => 'تصميم مبسط',
	'raccourcis_tableau' => 'الجداول'
);
