<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-aide?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aide_description' => 'يتيح هذا الملحق إدخال تعليمات فورية على SPIP يُدلّ اليها برمز معين. يمكن تعميم هذه التعليمات على ملاحق أخرى.',
	'aide_nom' => 'تعليمات SPIP',
	'aide_slogan' => 'تعليمات SPIP الفورية'
);
