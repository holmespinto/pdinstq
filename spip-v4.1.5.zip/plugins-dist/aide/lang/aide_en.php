<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/aide-aide?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// R
	'raccourcis' => 'Typographical shortcuts',
	'raccourcis_ancre' => 'Named anchors',
	'raccourcis_citation' => 'Quotes',
	'raccourcis_code' => 'Programming code',
	'raccourcis_glossaire' => 'External glossary',
	'raccourcis_lien' => 'Hypertext links',
	'raccourcis_liste' => 'Lists and enumerations',
	'raccourcis_note' => 'Footnotes',
	'raccourcis_resume' => 'In short',
	'raccourcis_simple' => 'Simple formatting',
	'raccourcis_tableau' => 'Tables'
);
