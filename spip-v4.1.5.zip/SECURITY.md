# Security Policy

## Signaler une faille de sécurité

Voir https://www.spip.net/fr_article6688.html

## Reporting a Vulnerability

See https://www.spip.net/en_article6689.html